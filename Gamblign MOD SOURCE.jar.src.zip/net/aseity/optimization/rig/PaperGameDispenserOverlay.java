/*     */ package net.aseity.optimization.rig;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
/*     */ import net.minecraft.class_1703;
/*     */ import net.minecraft.class_1735;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2371;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_465;
/*     */ import net.minecraft.class_9334;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PaperGameDispenserOverlay
/*     */ {
/*     */   private static final int DISPENSER_TEXTURE_WIDTH = 176;
/*     */   private static final int DISPENSER_TEXTURE_HEIGHT = 166;
/*     */   private static final int GRID_ORIGIN_X = 62;
/*     */   private static final int GRID_ORIGIN_Y = 17;
/*     */   private static final int SLOT_STEP = 18;
/*  41 */   private static final Map<class_465<?>, HiddenSlotState> HIDDEN = new WeakHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void init() {
/*  47 */     ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
/*     */           class_465<?> handled;
/*     */           if (screen instanceof class_465) {
/*     */             handled = (class_465)screen;
/*     */           } else {
/*     */             return;
/*     */           } 
/*     */           class_1703 handler = handled.method_17577();
/*     */           if (!(handler instanceof net.minecraft.class_1716)) {
/*     */             return;
/*     */           }
/*     */           int sw = scaledWidth;
/*     */           int sh = scaledHeight;
/*     */           ScreenEvents.beforeRender(screen).register(());
/*     */           ScreenEvents.afterRender(screen).register(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void beforeRenderDispenser(class_465<?> screen) {
/*  78 */     if (!LegitRigController.isOverlayEnabled()) {
/*  79 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     class_1703 handler = screen.method_17577();
/*     */     
/*  85 */     if (!(handler instanceof net.minecraft.class_1716)) {
/*  86 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  91 */     if (!LegitRigController.hasActiveRigMapping()) {
/*  92 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     int riggedDigit = LegitRigController.getLastRiggedDigit();
/*  97 */     if (riggedDigit < 1 || riggedDigit > 9) {
/*  98 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 102 */     class_2371<class_1735> class_2371 = handler.field_7761;
/* 103 */     if (class_2371.size() < 9) {
/* 104 */       restoreHiddenIfAny(screen);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 110 */     class_1792 activeItem = LegitRigController.getActiveItem();
/* 111 */     if (activeItem == null) {
/* 112 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 116 */     boolean hasActiveItemInGrid = false;
/* 117 */     for (int i = 0; i < 9; i++) {
/* 118 */       class_1799 s = ((class_1735)class_2371.get(i)).method_7677();
/* 119 */       if (!s.method_7960() && s.method_31574(activeItem)) {
/* 120 */         hasActiveItemInGrid = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 124 */     if (!hasActiveItemInGrid) {
/*     */       
/* 126 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 131 */     int emptyCount = 0;
/* 132 */     int realMissingIndex = -1;
/* 133 */     for (int j = 0; j < 9; j++) {
/* 134 */       class_1799 stack = ((class_1735)class_2371.get(j)).method_7677();
/* 135 */       if (stack.method_7960()) {
/* 136 */         emptyCount++;
/* 137 */         realMissingIndex = j;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 142 */     if (emptyCount != 1 || realMissingIndex < 0) {
/* 143 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 147 */     int hideIndex = riggedDigit - 1;
/* 148 */     if (hideIndex < 0 || hideIndex > 8 || hideIndex == realMissingIndex) {
/*     */       
/* 150 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 154 */     class_1735 hideSlot = class_2371.get(hideIndex);
/* 155 */     class_1799 hideStack = hideSlot.method_7677();
/* 156 */     if (hideStack.method_7960()) {
/*     */       
/* 158 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 162 */     HiddenSlotState state = HIDDEN.computeIfAbsent(screen, k -> new HiddenSlotState());
/*     */ 
/*     */     
/* 165 */     if (state.hideIndex >= 0 && !state.hiddenStack.method_7960() && 
/* 166 */       state.hideIndex < handler.field_7761.size()) {
/* 167 */       ((class_1735)handler.field_7761.get(state.hideIndex)).method_53512(state.hiddenStack);
/*     */     }
/*     */ 
/*     */     
/* 171 */     state.hideIndex = hideIndex;
/* 172 */     state.realMissingIndex = realMissingIndex;
/* 173 */     state.hiddenStack = hideStack.method_7972();
/*     */ 
/*     */     
/* 176 */     hideSlot.method_53512(class_1799.field_8037);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void afterRenderDispenser(class_465<?> screen, class_332 context, int screenWidth, int screenHeight) {
/* 184 */     if (!LegitRigController.isOverlayEnabled()) {
/* 185 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 189 */     class_1703 handler = screen.method_17577();
/* 190 */     if (!(handler instanceof net.minecraft.class_1716)) {
/* 191 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 195 */     HiddenSlotState state = HIDDEN.get(screen);
/* 196 */     if (state == null || state.realMissingIndex < 0) {
/* 197 */       restoreHiddenIfAny(screen);
/*     */       
/*     */       return;
/*     */     } 
/* 201 */     class_2371<class_1735> class_2371 = handler.field_7761;
/* 202 */     if (class_2371.size() < 9) {
/* 203 */       restoreHiddenIfAny(screen);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 209 */     int realMissingIndex = state.realMissingIndex;
/* 210 */     int realDigit = realMissingIndex + 1;
/* 211 */     if (realDigit >= 1 && realDigit <= 9) {
/*     */       
/* 213 */       class_1799 template = class_1799.field_8037;
/* 214 */       for (int i = 0; i < 9; i++) {
/* 215 */         class_1799 s = ((class_1735)class_2371.get(i)).method_7677();
/* 216 */         if (!s.method_7960()) {
/* 217 */           template = s;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 222 */       if (template.method_7960() && state.hiddenStack != null && !state.hiddenStack.method_7960()) {
/* 223 */         template = state.hiddenStack;
/*     */       }
/*     */       
/* 226 */       if (!template.method_7960()) {
/* 227 */         class_1799 fakeStack = template.method_7972();
/* 228 */         fakeStack.method_7939(1);
/* 229 */         fakeStack.method_57379(class_9334.field_49631, class_2561.method_43470(Integer.toString(realDigit)));
/*     */         
/* 231 */         class_310 client = class_310.method_1551();
/* 232 */         if (client != null) {
/* 233 */           int guiLeft = (screenWidth - 176) / 2;
/* 234 */           int guiTop = (screenHeight - 166) / 2;
/*     */           
/* 236 */           int col = realMissingIndex % 3;
/* 237 */           int row = realMissingIndex / 3;
/* 238 */           int rx = guiLeft + 62 + col * 18;
/* 239 */           int ry = guiTop + 17 + row * 18;
/*     */           
/* 241 */           context.method_51427(fakeStack, rx, ry);
/* 242 */           context.method_51431(client.field_1772, fakeStack, rx, ry);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 248 */     restoreHiddenIfAny(screen);
/*     */   }
/*     */   
/*     */   private static void restoreHiddenIfAny(class_465<?> screen) {
/* 252 */     HiddenSlotState state = HIDDEN.get(screen);
/* 253 */     if (state == null) {
/*     */       return;
/*     */     }
/*     */     
/* 257 */     if (state.hideIndex >= 0 && !state.hiddenStack.method_7960()) {
/* 258 */       class_1703 handler = screen.method_17577();
/* 259 */       if (state.hideIndex < handler.field_7761.size()) {
/* 260 */         ((class_1735)handler.field_7761.get(state.hideIndex)).method_53512(state.hiddenStack);
/*     */       }
/*     */     } 
/*     */     
/* 264 */     state.hideIndex = -1;
/* 265 */     state.realMissingIndex = -1;
/* 266 */     state.hiddenStack = class_1799.field_8037;
/*     */   }
/*     */   
/*     */   private static final class HiddenSlotState {
/* 270 */     int hideIndex = -1;
/* 271 */     int realMissingIndex = -1;
/* 272 */     class_1799 hiddenStack = class_1799.field_8037;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\smarttweaks.jar!\net\aseity\optimization\rig\PaperGameDispenserOverlay.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */