/*     */ package net.aseity.optimization.rig;
/*     */ 
/*     */ import net.aseity.optimization.gui.OptimizationSettingsScreen;
/*     */ import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
/*     */ import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1703;
/*     */ import net.minecraft.class_1735;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3675;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_746;
/*     */ import net.minecraft.class_9334;
/*     */ import net.minecraft.class_9779;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LegitRigController
/*     */ {
/*     */   private static boolean enabled = true;
/*     */   private static boolean overlayEnabled = true;
/*  32 */   private static class_1792 sideA = class_1802.field_8288;
/*  33 */   private static class_1792 sideB = class_1802.field_8301;
/*     */ 
/*     */   
/*  36 */   private static int activeSideIndex = 0;
/*     */ 
/*     */ 
/*     */   
/*  40 */   private static int currentOppDigit = -1;
/*     */   
/*  42 */   private static int riggedDigit = -1;
/*     */ 
/*     */   
/*     */   private static boolean mappingActive = false;
/*     */   
/*  47 */   private static int lastRealDigit = -1;
/*  48 */   private static int lastRiggedDigit = -1;
/*     */ 
/*     */   
/*  51 */   private static int toggleRigKeyCode = 71;
/*  52 */   private static int switchSideKeyCode = 72;
/*  53 */   private static int overlayToggleKeyCode = 79;
/*  54 */   private static int openSettingsKeyCode = 80;
/*     */ 
/*     */   
/*     */   private static boolean toggleRigWasDown = false;
/*     */ 
/*     */   
/*     */   private static boolean switchSideWasDown = false;
/*     */ 
/*     */   
/*     */   private static boolean overlayToggleWasDown = false;
/*     */ 
/*     */   
/*     */   private static boolean openSettingsWasDown = false;
/*     */ 
/*     */   
/*     */   private static boolean canProcessHotkeys(class_310 mc) {
/*  70 */     if (mc == null || mc.field_1724 == null) return false;
/*     */ 
/*     */     
/*  73 */     if (mc.field_1755 instanceof OptimizationSettingsScreen) {
/*  74 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  78 */     if (mc.field_1755 == null) {
/*  79 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  83 */     if (mc.field_1755 instanceof net.minecraft.class_465) {
/*  84 */       return true;
/*     */     }
/*     */ 
/*     */     
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void init() {
/*  93 */     ClientTickEvents.END_CLIENT_TICK.register(client -> {
/*     */           if (client == null) {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/*     */           class_746 class_746 = client.field_1724;
/*     */ 
/*     */           
/*     */           long handle = client.method_22683().method_4490();
/*     */ 
/*     */           
/*     */           boolean toggleRigDown = class_3675.method_15987(handle, toggleRigKeyCode);
/*     */ 
/*     */           
/*     */           boolean switchSideDown = class_3675.method_15987(handle, switchSideKeyCode);
/*     */ 
/*     */           
/*     */           boolean overlayToggleDown = class_3675.method_15987(handle, overlayToggleKeyCode);
/*     */ 
/*     */           
/*     */           boolean openSettingsDown = class_3675.method_15987(handle, openSettingsKeyCode);
/*     */           
/*     */           boolean canProcess = canProcessHotkeys(client);
/*     */           
/*     */           if (toggleRigDown && !toggleRigWasDown && canProcess) {
/*     */             if (class_746 != null) {
/*     */               revertRig((class_1657)class_746);
/*     */             }
/*     */             
/*     */             enabled = !enabled;
/*     */           } 
/*     */           
/*     */           if (switchSideDown && !switchSideWasDown && canProcess) {
/*     */             if (class_746 != null) {
/*     */               revertRig((class_1657)class_746);
/*     */             }
/*     */             
/*     */             activeSideIndex = 1 - activeSideIndex;
/*     */             
/*     */             clearMapping();
/*     */           } 
/*     */           
/*     */           if (overlayToggleDown && !overlayToggleWasDown && canProcess) {
/*     */             overlayEnabled = !overlayEnabled;
/*     */           }
/*     */           
/*     */           if (openSettingsDown && !openSettingsWasDown && canProcess) {
/*     */             openSettingsScreen(client);
/*     */           }
/*     */           
/*     */           toggleRigWasDown = toggleRigDown;
/*     */           
/*     */           switchSideWasDown = switchSideDown;
/*     */           
/*     */           overlayToggleWasDown = overlayToggleDown;
/*     */           
/*     */           openSettingsWasDown = openSettingsDown;
/*     */           
/*     */           if (!enabled || class_746 == null) {
/*     */             return;
/*     */           }
/*     */           
/*     */           applyRig((class_1657)class_746);
/*     */         });
/*     */     
/* 159 */     HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
/*     */           class_310 client = class_310.method_1551();
/*     */           if (client == null || client.field_1690.field_1842 || !overlayEnabled) {
/*     */             return;
/*     */           }
/*     */           int x = 4;
/*     */           int y = 4;
/*     */           int color = enabled ? -16711936 : -65536;
/*     */           ctx.method_25294(x, y, x + 8, y + 8, color);
/*     */           class_1792 activeItem = getActiveItem();
/*     */           if (activeItem != null) {
/*     */             class_1799 itemStack = new class_1799((class_1935)activeItem);
/*     */             ctx.method_51427(itemStack, x + 12, y);
/*     */             ctx.method_51431(client.field_1772, itemStack, x + 12, y);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnabled() {
/* 185 */     return enabled;
/*     */   }
/*     */   
/*     */   public static void setEnabled(boolean value) {
/* 189 */     if (enabled == value) {
/*     */       return;
/*     */     }
/* 192 */     enabled = value;
/*     */   }
/*     */   
/*     */   public static void switchSide() {
/* 196 */     activeSideIndex = 1 - activeSideIndex;
/* 197 */     clearMapping();
/*     */   }
/*     */   
/*     */   public static class_1792 getSideA() {
/* 201 */     return sideA;
/*     */   }
/*     */   
/*     */   public static class_1792 getSideB() {
/* 205 */     return sideB;
/*     */   }
/*     */   
/*     */   public static void setSideA(class_1792 item) {
/* 209 */     if (item != null) {
/* 210 */       sideA = item;
/* 211 */       clearMapping();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setSideB(class_1792 item) {
/* 216 */     if (item != null) {
/* 217 */       sideB = item;
/* 218 */       clearMapping();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getActiveSideLabel() {
/* 223 */     class_1792 active = getActiveItem();
/* 224 */     return active.method_7848().getString();
/*     */   }
/*     */   
/*     */   public static int getToggleRigKeyCode() {
/* 228 */     return toggleRigKeyCode;
/*     */   }
/*     */   
/*     */   public static void setToggleRigKeyCode(int keyCode) {
/* 232 */     toggleRigKeyCode = keyCode;
/*     */   }
/*     */   
/*     */   public static int getSwitchSideKeyCode() {
/* 236 */     return switchSideKeyCode;
/*     */   }
/*     */   
/*     */   public static void setSwitchSideKeyCode(int keyCode) {
/* 240 */     switchSideKeyCode = keyCode;
/*     */   }
/*     */   
/*     */   public static boolean isOverlayEnabled() {
/* 244 */     return overlayEnabled;
/*     */   }
/*     */   
/*     */   public static void setOverlayEnabled(boolean value) {
/* 248 */     overlayEnabled = value;
/*     */   }
/*     */   
/*     */   public static int getOverlayToggleKeyCode() {
/* 252 */     return overlayToggleKeyCode;
/*     */   }
/*     */   
/*     */   public static void setOverlayToggleKeyCode(int keyCode) {
/* 256 */     overlayToggleKeyCode = keyCode;
/*     */   }
/*     */   
/*     */   public static int getOpenSettingsKeyCode() {
/* 260 */     return openSettingsKeyCode;
/*     */   }
/*     */   
/*     */   public static void setOpenSettingsKeyCode(int keyCode) {
/* 264 */     openSettingsKeyCode = keyCode;
/*     */   }
/*     */   
/*     */   private static void openSettingsScreen(class_310 client) {
/* 268 */     if (client == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 273 */     if (client.field_1755 instanceof OptimizationSettingsScreen) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 279 */     client.method_1507((class_437)new OptimizationSettingsScreen(client.field_1755));
/*     */   }
/*     */   
/*     */   public static int getLastRealDigit() {
/* 283 */     return lastRealDigit;
/*     */   }
/*     */   
/*     */   public static int getLastRiggedDigit() {
/* 287 */     return lastRiggedDigit;
/*     */   }
/*     */   
/*     */   public static boolean hasActiveRigMapping() {
/* 291 */     return (mappingActive && riggedDigit >= 0 && riggedDigit <= 9 && lastRealDigit >= 0 && lastRealDigit <= 9);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearMapping() {
/* 297 */     mappingActive = false;
/* 298 */     riggedDigit = -1;
/* 299 */     currentOppDigit = -1;
/* 300 */     lastRealDigit = -1;
/* 301 */     lastRiggedDigit = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_1792 getActiveItem() {
/* 307 */     return (activeSideIndex == 0) ? sideA : sideB;
/*     */   }
/*     */   
/*     */   private static class_1792 getOppositeItem() {
/* 311 */     return (activeSideIndex == 0) ? sideB : sideA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void revertRig(class_1657 player) {
/* 319 */     if (!hasActiveRigMapping()) {
/* 320 */       clearMapping();
/*     */       
/*     */       return;
/*     */     } 
/* 324 */     class_1792 rigItem = getActiveItem();
/* 325 */     int fromDigit = riggedDigit;
/* 326 */     int toDigit = lastRealDigit;
/*     */     
/* 328 */     if (fromDigit < 0 || toDigit < 0) {
/* 329 */       clearMapping();
/*     */       
/*     */       return;
/*     */     } 
/* 333 */     class_310 client = class_310.method_1551();
/* 334 */     if (client == null) {
/* 335 */       clearMapping();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 340 */     class_1661 inv = player.method_31548();
/* 341 */     int size = inv.method_5439();
/* 342 */     for (int i = 0; i < size; i++) {
/* 343 */       class_1799 stack = inv.method_5438(i);
/* 344 */       revertStackDigit(stack, rigItem, fromDigit, toDigit);
/*     */     } 
/*     */ 
/*     */     
/* 348 */     class_1703 handler = player.field_7512;
/* 349 */     if (handler != null) {
/* 350 */       for (class_1735 slot : handler.field_7761) {
/* 351 */         class_1799 stack = slot.method_7677();
/* 352 */         revertStackDigit(stack, rigItem, fromDigit, toDigit);
/*     */       } 
/*     */       
/* 355 */       class_1799 cursor = handler.method_34255();
/* 356 */       revertStackDigit(cursor, rigItem, fromDigit, toDigit);
/*     */     } 
/*     */     
/* 359 */     clearMapping();
/*     */   }
/*     */   
/*     */   private static void revertStackDigit(class_1799 stack, class_1792 rigItem, int fromDigit, int toDigit) {
/* 363 */     if (stack == null || stack.method_7960() || !stack.method_31574(rigItem)) {
/*     */       return;
/*     */     }
/* 366 */     int cur = readDigitValue(stack);
/* 367 */     if (cur == fromDigit) {
/* 368 */       writeDigitValue(stack, toDigit);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void applyRig(class_1657 player) {
/* 373 */     class_1792 activeItem = getActiveItem();
/* 374 */     class_1792 oppItem = getOppositeItem();
/*     */ 
/*     */     
/* 377 */     int activeDigit = findDigitForItem(player, activeItem);
/* 378 */     int oppDigit = findDigitForItem(player, oppItem);
/*     */ 
/*     */     
/* 381 */     updateMappingSimple(activeDigit, oppDigit);
/*     */ 
/*     */     
/* 384 */     if (!mappingActive || riggedDigit < 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 389 */     class_1661 inv = player.method_31548();
/* 390 */     int size = inv.method_5439();
/* 391 */     for (int i = 0; i < size; i++) {
/* 392 */       class_1799 stack = inv.method_5438(i);
/* 393 */       forceRigOnStack(stack, activeItem);
/*     */     } 
/*     */ 
/*     */     
/* 397 */     class_1703 handler = player.field_7512;
/* 398 */     if (handler != null) {
/*     */ 
/*     */       
/* 401 */       if (handler instanceof net.minecraft.class_1716) {
/*     */         
/* 403 */         for (int j = 9; j < handler.field_7761.size(); j++) {
/* 404 */           class_1799 stack = ((class_1735)handler.field_7761.get(j)).method_7677();
/* 405 */           forceRigOnStack(stack, activeItem);
/*     */         } 
/*     */       } else {
/* 408 */         for (class_1735 slot : handler.field_7761) {
/* 409 */           class_1799 stack = slot.method_7677();
/* 410 */           forceRigOnStack(stack, activeItem);
/*     */         } 
/*     */       } 
/*     */       
/* 414 */       class_1799 cursor = handler.method_34255();
/* 415 */       forceRigOnStack(cursor, activeItem);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int findDigitForItem(class_1657 player, class_1792 item) {
/* 424 */     if (item == null) {
/* 425 */       return -1;
/*     */     }
/*     */     
/* 428 */     class_310 client = class_310.method_1551();
/* 429 */     if (client == null) {
/* 430 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 434 */     class_1661 inv = player.method_31548();
/* 435 */     int size = inv.method_5439();
/* 436 */     for (int i = 0; i < size; i++) {
/* 437 */       class_1799 stack = inv.method_5438(i);
/* 438 */       if (!stack.method_7960() && stack.method_31574(item)) {
/* 439 */         int d = readDigitValue(stack);
/* 440 */         if (d != -1) {
/* 441 */           return d;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 447 */     class_1703 handler = player.field_7512;
/* 448 */     if (handler != null) {
/* 449 */       if (!(handler instanceof net.minecraft.class_1716)) {
/* 450 */         for (class_1735 slot : handler.field_7761) {
/* 451 */           class_1799 stack = slot.method_7677();
/* 452 */           if (!stack.method_7960() && stack.method_31574(item)) {
/* 453 */             int d = readDigitValue(stack);
/* 454 */             if (d != -1) {
/* 455 */               return d;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 462 */       class_1799 cursor = handler.method_34255();
/* 463 */       if (!cursor.method_7960() && cursor.method_31574(item)) {
/* 464 */         int d = readDigitValue(cursor);
/* 465 */         if (d != -1) {
/* 466 */           return d;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 471 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void updateMappingSimple(int activeDigit, int oppDigit) {
/* 484 */     if (mappingActive) {
/*     */ 
/*     */       
/* 487 */       if (activeDigit == -1 && oppDigit == -1) {
/* 488 */         clearMapping();
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 496 */     if (activeDigit == -1 || oppDigit == -1) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 502 */     if (activeDigit >= oppDigit) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 507 */     int newRig = (oppDigit >= 9) ? 9 : (oppDigit + 1);
/*     */     
/* 509 */     mappingActive = true;
/* 510 */     currentOppDigit = oppDigit;
/* 511 */     riggedDigit = newRig;
/*     */     
/* 513 */     lastRealDigit = activeDigit;
/* 514 */     lastRiggedDigit = newRig;
/*     */   }
/*     */   
/*     */   private static void forceRigOnStack(class_1799 stack, class_1792 rigItem) {
/* 518 */     if (stack == null || stack.method_7960() || !stack.method_31574(rigItem)) {
/*     */       return;
/*     */     }
/* 521 */     if (!mappingActive || riggedDigit < 0) {
/*     */       return;
/*     */     }
/*     */     
/* 525 */     int cur = readDigitValue(stack);
/* 526 */     if (cur == -1 || cur == riggedDigit) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 532 */     writeDigitValue(stack, riggedDigit);
/*     */   }
/*     */   
/*     */   private static int readDigitValue(class_1799 stack) {
/* 536 */     if (stack == null || stack.method_7960()) {
/* 537 */       return -1;
/*     */     }
/*     */     
/* 540 */     String name = stack.method_7964().getString().trim();
/* 541 */     if (name.length() != 1) {
/* 542 */       return -1;
/*     */     }
/*     */     
/* 545 */     char c = name.charAt(0);
/* 546 */     if (c < '0' || c > '9') {
/* 547 */       return -1;
/*     */     }
/*     */     
/* 550 */     return c - 48;
/*     */   }
/*     */   
/*     */   private static void writeDigitValue(class_1799 stack, int value) {
/* 554 */     if (value < 0 || value > 9) {
/*     */       return;
/*     */     }
/*     */     
/* 558 */     stack.method_57379(class_9334.field_49631, class_2561.method_43470(Integer.toString(value)));
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\smarttweaks.jar!\net\aseity\optimization\rig\LegitRigController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */