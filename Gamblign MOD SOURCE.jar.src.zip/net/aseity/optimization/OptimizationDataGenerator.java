package net.aseity.optimization;

import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;

public class OptimizationDataGenerator implements DataGeneratorEntrypoint {
  public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {}
}


/* Location:              C:\Users\simon\Downloads\smarttweaks.jar!\net\aseity\optimization\OptimizationDataGenerator.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */