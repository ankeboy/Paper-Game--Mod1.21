/*    */ package net.aseity.optimization.integration;
/*    */ 
/*    */ import com.terraformersmc.modmenu.api.ConfigScreenFactory;
/*    */ import net.aseity.optimization.gui.OptimizationSettingsScreen;
/*    */ import net.minecraft.class_437;
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ConfigScreenFactory<class_437>
/*    */ {
/*    */   null(OptimizationModMenuIntegration this$0) {}
/*    */   
/*    */   public class_437 create(class_437 parent) {
/* 15 */     return (class_437)new OptimizationSettingsScreen(parent);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\smarttweaks.jar!\net\aseity\optimization\integration\OptimizationModMenuIntegration$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */