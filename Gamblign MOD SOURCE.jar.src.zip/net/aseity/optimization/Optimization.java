/*    */ package net.aseity.optimization;
/*    */ 
/*    */ import net.aseity.optimization.rig.LegitRigController;
/*    */ import net.aseity.optimization.rig.PaperGameDispenserOverlay;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.api.ModInitializer;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class Optimization
/*    */   implements ModInitializer, ClientModInitializer
/*    */ {
/*    */   public static final String MOD_ID = "optimization";
/* 14 */   public static final Logger LOGGER = LoggerFactory.getLogger("optimization");
/*    */ 
/*    */ 
/*    */   
/*    */   public void onInitialize() {
/* 19 */     LOGGER.info("[optimization] Common module initialized.");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onInitializeClient() {
/* 25 */     LOGGER.info("[optimization] Client module initialized.");
/* 26 */     LegitRigController.init();
/* 27 */     PaperGameDispenserOverlay.init();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\smarttweaks.jar!\net\aseity\optimization\Optimization.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */