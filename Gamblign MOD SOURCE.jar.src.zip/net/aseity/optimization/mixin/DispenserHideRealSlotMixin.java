/*     */ package net.aseity.optimization.mixin;
/*     */ 
/*     */ import net.aseity.optimization.rig.LegitRigController;
/*     */ import net.minecraft.class_1703;
/*     */ import net.minecraft.class_1735;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2371;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_465;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Inject;
/*     */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_465.class})
/*     */ public abstract class DispenserHideRealSlotMixin
/*     */ {
/*     */   @Shadow
/*     */   protected class_1703 field_2797;
/*     */   
/*     */   @Inject(method = {"method_2385(Lnet/minecraft/class_332;Lnet/minecraft/class_1735;)V"}, at = {@At("HEAD")}, cancellable = true)
/*     */   private void optimization$hideRiggedDispenserSlot(class_332 context, class_1735 slot, CallbackInfo ci) {
/*  35 */     if (!(this.field_2797 instanceof net.minecraft.class_1716)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  40 */     if (!LegitRigController.hasActiveRigMapping()) {
/*     */       return;
/*     */     }
/*     */     
/*  44 */     int riggedDigit = LegitRigController.getLastRiggedDigit();
/*  45 */     if (riggedDigit < 1 || riggedDigit > 9) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  51 */     class_1792 activeItem = LegitRigController.getActiveItem();
/*  52 */     if (activeItem == null) {
/*     */       return;
/*     */     }
/*     */     
/*  56 */     class_2371<class_1735> class_2371 = this.field_2797.field_7761;
/*  57 */     if (class_2371.size() < 9) {
/*     */       return;
/*     */     }
/*     */     
/*  61 */     boolean hasActiveItemInGrid = false;
/*  62 */     for (int i = 0; i < 9; i++) {
/*  63 */       class_1799 s = ((class_1735)class_2371.get(i)).method_7677();
/*  64 */       if (!s.method_7960() && s.method_31574(activeItem)) {
/*  65 */         hasActiveItemInGrid = true;
/*     */         break;
/*     */       } 
/*     */     } 
/*  69 */     if (!hasActiveItemInGrid) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     int emptyCount = 0;
/*  78 */     for (int j = 0; j < 9; j++) {
/*  79 */       if (((class_1735)class_2371.get(j)).method_7677().method_7960()) {
/*  80 */         emptyCount++;
/*     */       }
/*     */     } 
/*  83 */     if (emptyCount != 1) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  88 */     int slotIndex = class_2371.indexOf(slot);
/*  89 */     if (slotIndex < 0 || slotIndex > 8) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  94 */     int riggedIndex = riggedDigit - 1;
/*     */     
/*  96 */     if (slotIndex == riggedIndex)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       ci.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\smarttweaks.jar!\net\aseity\optimization\mixin\DispenserHideRealSlotMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */